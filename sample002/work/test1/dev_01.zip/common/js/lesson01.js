﻿var CodeChap="01";//차시번호
var NumChap=Number(CodeChap);

var PageInfo = new Array();
PageInfo[1] =["noTxt","0100","t_None","s_None",	[0,"t_ctrl_1","t_None"],	[0,"t_None","t_None"], "false"];
PageInfo[2] =["okTxt","0101","t_None","s_None",	[0,"t_ctrl_1","t_None"],	[0,"t_None","t_None"], "false"];
PageInfo[3] =["okTxt","0102","t_None","s_None",	[0,"t_ctrl_1","t_None"],	[0,"t_None","t_None"], "false"];

PageInfo[4] =["okTxt","0201","t_None","s_None",	[0,"t_ctrl_1","t_None"],	[0,"t_None","t_mov_5"], "true"];
PageInfo[5] =["okTxt","0202","t_None","s_None",	[0,"t_ctrl_1","t_None"],	[0,"t_None","t_mov_5"], "true"];
PageInfo[6] =["okTxt","0203","t_None","s_None",	[0,"t_ctrl_1","t_None"],	[0,"t_None","t_mov_5"], "true"];
PageInfo[7] =["okTxt","0204","t_None","s_None",	[0,"t_ctrl_1","t_None"],	[0,"t_None","t_mov_5"], "true"];


PageInfo[8] =["okTxt","0301","t_None","s_None",	[0,"t_ctrl_1","t_None"],	[0,"t_None","t_None"], "false"];
PageInfo[9] =["okTxt","0302","t_None","s_None",	[0,"t_ctrl_1","t_quiz_1"],	[0,"t_None","t_None"], "false"];
PageInfo[10] =["okTxt","0401","t_None","s_None",[0,"t_ctrl_1","t_None"],	[0,"t_None","t_None"], "false"];
